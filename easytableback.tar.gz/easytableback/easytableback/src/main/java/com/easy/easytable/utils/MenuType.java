package com.easy.easytable.utils;

public enum MenuType {ENFANT, JUNIOR, DECOUVERTE, DEGUSTATION, DU_JOUR
}
