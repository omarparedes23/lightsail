package com.easy.easytable.utils;

public enum RestaurantType {FAST_FOOD, BRASSERIE, CUISINE_DU_MONDE
}
