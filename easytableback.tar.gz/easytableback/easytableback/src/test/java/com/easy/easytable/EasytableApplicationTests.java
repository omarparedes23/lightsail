package com.easy.easytable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class EasytableApplicationTests {

	@Test
	void contextLoads() {
	}

}
