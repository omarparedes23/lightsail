import { Component,OnInit } from '@angular/core';
//import { FaceSnap } from './models/face-snap.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  //faceSnaps!: FaceSnap[];
  //mySnap!: FaceSnap;
  //myOtherSnap!: FaceSnap;
  //myLastSnap!: FaceSnap;

  ngOnInit() { }
}
