export interface Itablerestaurant {
  id: number;
  restaurant_id: number;
}
