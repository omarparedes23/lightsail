export interface Iclient {
  id: number;
  codepostal: string;
  email: string;
  nom: string;
  prenom: string;
  rue: string;
  telephone: string;
  ville: string;
}
