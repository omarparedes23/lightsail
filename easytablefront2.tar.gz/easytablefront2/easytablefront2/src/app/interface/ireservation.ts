export interface Ireservation {
  dateReservation: string;
  heureReservation: string;
  nombrePersonnes: number;
  clientId: number;
  tablerestaurantId: number;
}
