export interface Imenu {
  id: number;
  contenu: string;
  menuType: string;
  nom: string;
  prix: number;
  url: string;
}
