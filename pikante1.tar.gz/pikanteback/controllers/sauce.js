//const Sauce = require('../models/sauce');
const Sauce = require('./sauce');
const mongoose = require("mongoose");
const SauceModel = require('./Sauce');

const fs = require('fs');

exports.createSauce = (req, res, next) => {
let protocol = req.protocol;
console.log(protocol)
if (protocol === 'http') {
    protocol += 's'; // Agrega la 's' al protocolo para https
}

  const sauceObject = JSON.parse(req.body.sauce);
  delete sauceObject._id;
  delete sauceObject._userId;
console.log(sauceObject)
//console.log(${protocol})

  const sauce = new SauceModel({
    ...sauceObject,
    userId: req.auth.userId,
    imageUrl: `${protocol}://${req.get('host').split(":")[0]}/images/${req.file.filename}`
  });
  sauce.save()
    .then(() => { res.status(201).json({ message: 'Objet enregistré !' }) })
    .catch(error => { res.status(400).json({ error }) })
};







exports.modifySauce = (req, res, next) => {
let protocol = req.protocol;
console.log(protocol)
if (protocol === 'http') {
    protocol += 's'; // Agrega la 's' al protocolo para https
}

  const sauceObject = req.file ? {
    ...JSON.parse(req.body.sauce),
    imageUrl: `${protocol}://${req.get('host').split(":")[0]}/images/${req.file.filename}`
  } : { ...req.body };
  delete sauceObject._userId;
  SauceModel.findOne({ _id: req.params.id })
    .then((sauce) => {
      if (sauce.userId != req.auth.userId) {
        res.status(401).json({ message: 'Utilisateur non autorisé' });
      } else {
        if (req.file) {
          const filename = sauce.imageUrl.split('/images/')[1];
          fs.unlink(`images/${filename}`, () => {
          });
        }
        SauceModel.updateOne({ _id: req.params.id }, { ...sauceObject, _id: req.params.id })
          .then(() => res.status(200).json({ message: 'Objet modifié!' }))
          .catch(error => res.status(401).json({ error }));
      }
    })
    .catch((error) => {
      res.status(400).json({ error });
    });
};
exports.deleteSauce = (req, res, next) => {
  SauceModel.findOne({ _id: req.params.id })
    .then(sauce => {
      if (sauce.userId != req.auth.userId) {
        res.status(401).json({ message: 'Utilisateur non autorisé' });
      } else {
        const filename = sauce.imageUrl.split('/images/')[1];
        fs.unlink(`images/${filename}`, () => {
          SauceModel.deleteOne({ _id: req.params.id })
            .then(() => { res.status(200).json({ message: 'Objet supprimé !' }) })
            .catch(error => res.status(401).json({ error }));
        });
      }
    })
    .catch(error => {
      res.status(500).json({ error });
    });
};
exports.getOneSauce = (req, res, next) => {
  SauceModel.findOne({ _id: req.params.id })
    .then(sauce => res.status(200).json(sauce))
    .catch(error => res.status(404).json({ error }));
};
exports.getAllSauces1 = (req, res, next) => {
  Sauce.find()
    .then((sauces) => res.status(200).json(sauces))
    .catch((error) => res.status(400).json({ error }));
};

exports.getAllSauces = (req, res, next) => {
  SauceModel.find() // Usa el modelo importado
    .then((sauces) => res.status(200).json(sauces))
    .catch((error) => res.status(400).json({ error }));
};

// Handle Like / Dislike
exports.likerSauce = (req, res, next) => {
  SauceModel.findOne({ _id: req.params.id })
    .then((sauce) => {
      let param =
      {
        _id: req.params.id,
      }
      //modifier le statut si l'utilisateur a donné "Like"
      if (req.body.like == 1) {
        param =
        {
          $inc: { likes: +1 },
          $push: { usersLiked: req.auth.userId },
          _id: req.params.id,
        }
      }
      //effacer le statut si l'utilisateur a donné "Like" ou "Dislike"
      if (req.body.like == 0) {
        if (sauce.usersLiked.find((temp) => temp === req.auth.userId)) {
          param =
          {
            $inc: { likes: -1 },
            $pull: { usersLiked: req.auth.userId },
            _id: req.params.id,
          }

        }
        //
        if (sauce.usersDisliked.find((temp) => temp === req.auth.userId)) {
          param =
          {
            $inc: { dislikes: -1 },
            $pull: { usersDisliked: req.auth.userId },
            _id: req.params.id,
          }

        }

      }
      //modifier le statut si l'utilisateur a donné "Dislike"
      if (req.body.like == -1) {
        param =
        {
          $inc: { dislikes: +1 },
          $push: { usersDisliked: req.auth.userId },
          _id: req.params.id,
        }
      }

      SauceModel.updateOne({ _id: req.params.id }, param)
        .then(() => {
          res.status(201).json({ message: 'Modification Like/Dislike effectué' });
        })
        .catch((error) => {
          res.status(400).json({ error });
        });
    })
    .catch((error) => {
      res.status(400).json({ error });
    });
};
