const express = require('express');
const router = express.Router();
const userCtrl = require('../controllers/user');
const rateLimit = require("express-rate-limit");
//Limitez les demandes de connexion pour éviter Les attaques par force brute
const apiLimiter = rateLimit({
    windowMs: 10 * 60 * 1000,
    max: 5,
    standardHeaders: true,
    legacyHeaders: false,
});
router.post('/signup', userCtrl.signup);
router.post('/login', apiLimiter, userCtrl.login);
module.exports = router;